RECO algorithm
A Coordination Optimization Framework for Multi-Agent Reinforcement Learning Based on Reward Redistribution and Experience Reutilization.

## Method

**RECO** is a MARL framework For effective MI-driven collaboration.
a novel framework termed Reward redistribution and Experience reutilization based Coordination 4
Optimization (RECO). This innovative approach employs a hierarchical experience pool mechanism 5
that enhances exploration through strategic reward redistribution and experience reutilization. The 6
RECO framework incorporates a sophisticated evaluation system that assesses the quality of historical 7
sampling data from individual agents and optimizes reward distribution by maximizing mutual 8
information across hierarchical experience trajectories.

# Installation
Known dependencies: Python (3.6.13), OpenAI gym (0.10.5), torch (1.8.1+cu102), numpy (1.19.5), Multi-agent Particle Environment

## License & Acknowledgements

**RECO**  is licensed under the MIT license. [MPE](https://github.com/openai/multiagent-particle-envs) are licensed under the Apache 2.0 license. 